#ifndef MAIN_H
#define MAIN_H
void led_indicator_pulse(void);

#endif
